
package com.peisia.dto;

import java.util.List;

public class Items {

	public List<Item> item;

}
